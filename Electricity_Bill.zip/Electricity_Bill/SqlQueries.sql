CREATE TABLE USER_MASTER(user_id NUMBER(8) PRIMARY KEY, name VARCHAR2(100), mobileno VARCHAR2(10), 
username VARCHAR2(100),password VARCHAR2(100), repassword VARCHAR2(100));

CREATE SEQUENCE seq_user_master;


CREATE TABLE USER_PAY_MASTER(userpay_id NUMBER(8) PRIMARY KEY, name VARCHAR2(100),username VARCHAR2(100),
password VARCHAR2(100), amount VARCHAR2(100));

CREATE SEQUENCE seq_userpay_master;
