package com.cg.electricitybill.controller;

import java.io.IOException;

import javax.jms.Session;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;









import com.cg.electricitybill.dto.User;
import com.cg.electricitybill.dto.UserPay;
import com.cg.electricitybill.exception.UserException;
import com.cg.electricitybill.service.UserService;
import com.cg.electricitybill.service.UserServiceImpl;


@WebServlet("/UserFrontController")
public class UserFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    UserService userSer;
    public UserFrontController() {
        super();
       
        userSer=new UserServiceImpl();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		HttpSession usersession = request.getSession(true);
		int fixAmount=750;
		//usersession.setAttribute("amount", fixAmount);
		
		switch(action)
		{
		case "add":
			{
				
				User user=new User();
			
				String name= request.getParameter("name");
				String mobileNo = request.getParameter("mobileNo");
				String username = request.getParameter("username");
				String password = request.getParameter("password");
				String rePassword = request.getParameter("rePassword");
				
				if(password.equals(rePassword)){
				user.setName(name);
				user.setMobileNo(mobileNo);
				user.setUsername(username);
				user.setPassword(password);
				user.setRePassword(rePassword);
				
				usersession.setAttribute("user", user);
				
				
				try {
					
				       userSer.addUser(user);
				       usersession.setAttribute("name", name);
					   RequestDispatcher rd=request.getRequestDispatcher("paybill.jsp");
						rd.forward(request, response);
						
				} catch (UserException e) {
					
					RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
					request.setAttribute("errorMessage", e.getMessage());
					rd.forward(request, response);
				}
				}else{
					RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
					rd.forward(request, response);
				}
				
			}
			break;
		
		case "addamount":
		{
			UserPay pay=new UserPay();
			
			Object object = usersession.getAttribute("user");
			User user = (User) object;
			String amount = request.getParameter("amount");
			
			pay.setName(user.getName());
			pay.setUsername(user.getUsername());
			pay.setPassword(user.getPassword());
			pay.setAmount(amount);
			
			int remainAmount=fixAmount - Integer.parseInt(amount);
			
			try {
				
			       userSer.addAmount(pay);
				   RequestDispatcher rd=request.getRequestDispatcher("final.jsp");
				   request.setAttribute("remainAmount", remainAmount);
				   request.setAttribute("amount", amount);
				   rd.forward(request, response);
					
			} catch (UserException e) {
				
				RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
			}
			
			
		 }
		 break;
		}
	}

}
