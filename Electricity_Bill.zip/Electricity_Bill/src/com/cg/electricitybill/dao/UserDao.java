package com.cg.electricitybill.dao;

import com.cg.electricitybill.dto.User;
import com.cg.electricitybill.dto.UserPay;
import com.cg.electricitybill.exception.UserException;



public interface UserDao {

	public void addUser(User user) throws UserException;
	public void addAmount(UserPay pay) throws UserException;
}
