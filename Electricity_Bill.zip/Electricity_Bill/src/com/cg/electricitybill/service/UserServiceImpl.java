package com.cg.electricitybill.service;

import com.cg.electricitybill.dao.UserDao;
import com.cg.electricitybill.dao.UserDaoImpl;
import com.cg.electricitybill.dto.User;
import com.cg.electricitybill.dto.UserPay;
import com.cg.electricitybill.exception.UserException;

public class UserServiceImpl implements UserService {

	UserDao userDao= new UserDaoImpl();
	
	@Override
	public void addUser(User user) throws UserException {
		userDao.addUser(user);
		
	}

	@Override
	public void addAmount(UserPay pay) throws UserException {
		userDao.addAmount(pay);
		
	}

}
